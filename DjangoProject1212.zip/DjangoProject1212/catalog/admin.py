from django.contrib import admin
from catalog.models import Items,MyronchukSize

admin.site.register(Items)
admin.site.register(MyronchukSize)