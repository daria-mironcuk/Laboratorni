from django.db import models


class MyronchukSize(models.Model):
    title  = models.CharField(max_length=30)

    TYPE_SIZE = [
        ("M", "M"),
        ("L", "L"),
        ('S', 'S'),
        ('XL', 'XL'),
        ('XXL', 'XXL')
    ]

    class Meta:
        ordering = ["title"]

    def __str__(self):
        return self.title


class Items(models.Model):

    TYPE_PRODUCT = [
        ("t-shirt", "футболка"),
        ("poster", "плакат"),
        ('cup', 'кружка'),
        ('jacket', 'кофта')
    ]

    TYPE_CHOICES = [
        ('avialable', 'наявне'),
        ('notavialable', 'ненаявне')
    ]


    name = models.CharField(max_length=100, verbose_name='Назва', null=True, blank=True )
    weight = models.FloatField(verbose_name='вага (кг)', null=True, blank=True)
    image = models.ImageField(verbose_name='Зображення', upload_to='images/', null=True, blank=True)
    description = models.TextField(verbose_name='Опис' ,null=True, blank=True)
    type = models.CharField(max_length=20, choices=TYPE_PRODUCT, verbose_name='Тип', null=True, blank=True)
    autor = models.CharField(verbose_name='автор', max_length=50, null=True, blank=True)
    avialable = models.CharField(max_length=20, choices=TYPE_CHOICES, verbose_name='Наявність', null=True, blank=True)
    price = models.FloatField(verbose_name='Ціна (грн)', null=True, blank=True)
    size = models.ManyToManyField(MyronchukSize)


    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name