from django.shortcuts import render

def home(request):
    context = {'title': 'home'}
    return render(request, 'catalog/home.html', context)
def view1(request):
    context = {'title': 'view1'}
    return render(request, 'catalog/view1.html', context)

def view2(request):
    context = {'title': 'view2'}
    return render(request, 'catalog/view2.html', context)

def view3(request):
    context = {'title': 'view3'}
    return render(request, 'catalog/view3.html', context)

def view4(request):
    context = {'title': 'view4'}
    return render(request, 'catalog/view4.html', context)

def view5(request):
    context = {'title': 'view5'}
    return render(request, 'catalog/view5.html', context)
# Create your views here.
